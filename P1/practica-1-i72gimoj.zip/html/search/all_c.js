var searchData=
[
  ['testmonomio',['testMonomio',['../funcionesAuxiliares_8hpp.html#ae14d8583268cbebf768d8fa328126c39',1,'ed']]]
];
