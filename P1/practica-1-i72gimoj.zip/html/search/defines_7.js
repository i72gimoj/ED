var searchData=
[
  ['place',['PLACE',['../macros_8hpp.html#ad040774f1528e8a40d3c1c525997050f',1,'macros.hpp']]],
  ['purple',['PURPLE',['../macros_8hpp.html#a0bb0b009e7a7390473ace4d98bd843c0',1,'macros.hpp']]]
];
