var searchData=
[
  ['faint',['FAINT',['../macros_8hpp.html#a543c147742f817b4991f7b988d182001',1,'macros.hpp']]]
];
