var searchData=
[
  ['potenciamonomios',['potenciaMonomios',['../operacionAmpliacionMonomio_8cpp.html#ad9ec328b0bac5d7aab363eda9c98ae4a',1,'ed']]]
];
